<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\Label;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ItemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //$items = Item::all()->sortByDesc('obtained');
        $items = Item::orderBy('obtained', 'desc')->paginate(10);
        $user = Auth::user();
        return view('site.logged', ['items' => $items, 'user' => $user]);
    }

    public function index_detailed(){

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(!Auth::user()->is_admin){
            abort(401);
        }
        $labels = Label::all();
        return view('site.item_form', ['labels' => $labels]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name'=> 'required|string',
            'description' => 'required|max:500',
            'obtained' => 'required|date',
            'image' => 'nullable|file',
        ]);

        if($request->hasFile('image')){
            $path = $request->file('image')->store('public');
            $item = Item::create([
                'name'=> $validated['name'],
                'description' => $validated['description'],
                'obtained' => $validated['obtained'],
                'image' => $path,
            ]);
            $label_ids = $request->input('label');
            if($label_ids != null){
                foreach($label_ids as $labeldId){
                    $item->labels()->attach($labeldId);
                }
            }
        }else{
            $item = Item::create($validated);
            $label_ids = $request->input('label');
            if($label_ids != null){
                foreach($label_ids as $labeldId){
                    $item->labels()->attach($labeldId);
                }
            }
        }

        $items = Item::orderBy('obtained', 'desc')->paginate(10);
        $user = Auth::user();
        return view('site.logged', ['items' => $items, 'user' => $user]);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $item = Item::findOrFail($id);
        $user = Auth::user();
        return view('site.details', ['id' => $id, 'item' => $item, 'user' => $user]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $item = Item::findOrFail($id);
        if(!Auth::user()->is_admin){
            abort(401);
        }
        $labels = Label::all();
        return view('site.item_form',['item' => $item, 'labels' => $labels]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'name'=> 'required|string',
            'description' => 'required|max:500',
            'obtained' => 'required|date',
            'image' => 'nullable|file',
        ]);
        $item = Item::findOrFail($id);
        if(!Auth::user()->is_admin){
            abort(401);
        }

        if($request->hasFile('image')){
            $path = $request->file('image')->store('public');
            $item->update([
                'name'=> $validated['name'],
                'description' => $validated['description'],
                'obtained' => $validated['obtained'],
                'image' => $path,
            ]);
            $item->labels()->detach();

            $label_ids = $request->input('label');
            if($label_ids != null){
                foreach($label_ids as $labeldId){
                    $item->labels()->attach($labeldId);
                }
            }
        }else{
            $item->update($validated);
            $item->labels()->detach();

            $label_ids = $request->input('label');
            if($label_ids != null){
                foreach($label_ids as $labeldId){
                    $item->labels()->attach($labeldId);
                }
            }
        }


        return redirect()->route('items.show', ['item' => $item->id]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $item = Item::findOrFail($id);
        if(!Auth::user()->is_admin){
            abort(401);
        }
        #dd($item);
        #$item->comments()->detach();
        #$item->labels()->detach();
        $item->delete();

        $items = Item::orderBy('obtained', 'desc')->paginate(10);
        $user = Auth::user();
        return view('site.logged', ['items' => $items, 'user' => $user]);
    }
}
