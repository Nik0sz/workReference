<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\Label;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use LVR\Colour\Hex;

class LabelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(!Auth::user()->is_admin){
            abort(401);
        }
        return view('site.label_form');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string',
            'display' => 'required',
            'color' => ['required', new Hex()],
        ]);
        #dd($validated);

        Label::insert([
            'name' => $validated['name'],
            'display' => $validated['display'],
            'color' => $validated['color'],
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $items = Item::orderBy('obtained', 'desc')->paginate(10);
        $user = Auth::user();
        return view('site.logged', ['items' => $items, 'user' => $user]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $label = Label::findOrFail($id);
        if(!Auth::user()->is_admin){
            abort(401);
        }
        return view('site.label_form', ['label' => $label]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'name' => 'required|string',
            'display' => 'required',
            'color' => ['required', new Hex()],
        ]);
        $label = Label::findOrFail($id);
        if(!Auth::user()->is_admin){
            abort(401);
        }
        #dd($label);
        $label->update([
            'name' => $validated['name'],
            'display' => $validated['display'],
            'color' => $validated['color'],
        ]);
        $label->save();

        $items = Item::orderBy('obtained', 'desc')->paginate(10);
        $user = Auth::user();
        return view('site.logged', ['items' => $items, 'user' => $user]);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
