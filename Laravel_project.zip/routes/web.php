<?php

use App\Http\Controllers\Item_NController;
use App\Http\Controllers\ItemController;
use App\Http\Controllers\LabelController;
use App\Models\Item;
use App\Models\Label;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/





Route::get('/', function () {
    return redirect()->route('n_items.index');
});

Route::get('/dashboard', function () {
    return redirect()->route('items.index');
})->middleware(['auth']);

Route::resource('n_items', Item_NController::class);
Route::resource('items', ItemController::class);
Route::resource('labels', LabelController::class);







Route::get('/logged', function(){
    $items = Item::all()->sortByDesc('obtained');
    $user = Auth::user();
    return view('site.logged', ['items' => $items, 'user' => $user]);
})->middleware(['auth']);

require __DIR__.'/auth.php';

#    $item = Item::where('id', '=', $id)->get();
#    return view('site.n_details', ['id' => $id, 'item' => $item]);
#})->name('details_1');
#Route::get('/n_details/{id}', function($id){
#
#Route::get('/details/{id}', function($id){
#    return redirect()->route(('items.show($id)'));
#})->name('details_2');
