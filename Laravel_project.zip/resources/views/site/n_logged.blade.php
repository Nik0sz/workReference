@extends('layouts.layout')

@section('title', 'Open Items')

@section('content')
    <div>
        <table class="table align-middle">
            <thead>
                <tr>
                    <th scope="col">Image</th>
                    <th scope="col">Name</th>
                    <th scope="col">Description</th>
                    <th scope="col">More Info</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($items as $item)
                    <tr>
                        <td>
                            <img src={{$item->image}} alt="">
                            <img src="{{ Illuminate\Support\Facades\Storage::url($item->image) }}" alt="" title="" />
                        </td>
                        <td>
                            <div>{{$item->name}}</div>
                        </td>
                        <td>
                            <div>{{substr(($item->description), 0, 50)}}...</div>
                        </td>
                        <td>
                            <a class="btn btn-outline-secondary" href="{{ route('n_items.show', ['n_item' => $item->id])}}">Details</a>
                            {{--<a href="{{ route('n_items.show', ['n_item' => $item->id])}}">Detail</a> --}}
                            {{--<?php# $url = route('details_1', ['id' => $item->id])?>--}}
                            {{--<a href="<?=#$url?>">Details</a>--}}
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    {{$items->links()}}
@endsection
