@extends('layouts.flayout')

@section('title', isset($label) ? 'Edit: '.$label->name : 'New Label')

@section('content')
    <h1>{{isset($label) ? 'Edit: '.$label->name : 'New Label'}}</h1>
    <form method="post" action="{{ isset($label) ? route('labels.update', ['label' => $label->id]) : route('labels.store') }}">
        @csrf
        @isset($label)
            @method('put')
        @endisset
        <div>
            <div>
                <input
                    type="text"
                    class="form-control @error('name') is-invalid @enderror"
                    name="name"
                    id="name"
                    placeholder="Name of the new Label"
                    value="{{ old('name', $item->name ?? '')}}"
                />
                @error('name')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div>
                <label><input
                    type="radio"
                    class="@error('display') is-invalid @enderror"
                    value="1"
                    name="display"
                >Visible</label>
                <br>
                <label><input
                    type="radio"
                    class="@error('display') is-invalid @enderror"
                    value="0"
                    name="display"
                >Not visible</label>
                @error('display')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div>
                <input
                    type="color"
                    class="form-control @error('color') is-invalid @enderror"
                    name="color"
                    id="color"
                    value="{{ old('color', $label->color ?? '')}}"
                >
                @error('color')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>
        <div class="row">
            <button type="submit" class="btn btn-primary">Save</button>
        </div>
    </form>
@endsection
