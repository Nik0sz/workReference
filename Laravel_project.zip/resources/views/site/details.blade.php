@extends('layouts.layout_detailed')

@section('title', 'Item Detail')

@section('d_content')
    <button onclick="window.location.href='{{ route('items.index') }}'">Main Page</button>
    <div>
        <table class="table align-middle">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Obtained</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <img src={{$item->image}} alt="">
                        <img src="{{ Illuminate\Support\Facades\Storage::url($item->image) }}" alt="" title="" />
                    </td>
                    <td>
                        <div>{{$item->name}}</div>
                    </td>
                    <td>
                        <div>{{$item->description}}</div>
                    </td>
                    <td>
                        <div>{{$item->obtained}}</div>
                    </td>
                    <td>
                        <a class="btn btn-outline-secondary" href="{{ route('items.edit', ['item' => $item->id])}}">Edit</a>
                        {{--<form action="{{ route('items.destroy', ['item' => $item->id]) }}" method="post">
                            @csrf
                            @method('delete')
                            <button class="btn btn-danger mx-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete" type="submit">
                                <i class="fa-solid fa-trash fa-fw fa-xl"></i>
                            </button>
                        </form>--}}
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
@endsection

@section('labels')
    <div>
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            @foreach ($item->labels as $label)
                @if ($label->display)
                <?php $c = $label->color ?>
                    <li style="background-color:<?=$c?>">{{$label->name}}</li>
                    @if (Auth::user()->is_admin)
                        <li style="background-color:<?=$c?>"><a class="btn btn-outline-secondary" href="{{ route('labels.edit', ['label' => $label->id])}}">Edit</a></li>
                    @endif
                @endif
            @endforeach
        </ul>
    </div>
@endsection

@section('comments')
    <div>
        @if (is_null($item->comments))
            <div>No comments</div>
        @else
            @foreach ($item->comments->sortBy('created_at') as $comment)
                <div class="card mb-3">
                    <div class="card-header d-flex">
                        <div class="me-auto"><span class="badge bg-secondary">#{{ $loop->index }}</span> | <strong>{{ $comment->user->name }}</strong> | {{ $comment->created_at }}</div>
                    </div>
                    <div class="card-body">
                        {{ $comment->text }}
                    </div>
                </div>
            @endforeach
        @endif
    </div>
@endsection
