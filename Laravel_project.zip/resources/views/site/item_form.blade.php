@extends('layouts.flayout')

@section('title', isset($item) ? 'Edit: '.$item->name : 'New Item')

@section('content')
    <h1>{{isset($item) ? 'Edit: '.$item->name : 'New Item'}}</h1>
    <form method="post" action="{{ isset($item) ? route('items.update', ['item' => $item->id]) : route('items.store') }}" enctype="multipart/form-data">
        @csrf
        @isset($item)
            @method('put')
        @endisset
        <div>
            <div>
                <input
                    type="text"
                    class="form-control @error('name') is-invalid @enderror"
                    name="name"
                    id="name"
                    placeholder="Name of the new Item"
                    value="{{ old('name', $item->name ?? '')}}"
                />
                @error('name')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="mb-3">
                <textarea class="form-control @error('description') is-invalid @enderror" name="description" id="description" cols="30" rows="10" placeholder="Description...">{{ old('description', $item->description ?? '')}}</textarea>
                @error('description')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div>
                <input
                    type="date"
                    class="form_control @error('obtained') is-invalid @enderror"
                    name="obtained"
                    id="obtained"
                    placeholder="The date,when the item was obtained"
                    value="{{ old('obtained', $item->obtained ?? '')}}"
                >
                @error('obtained')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>
        <div>
            <input
                type="file"
                class="form-control @error('image') is-invalid @enderror"
                id="image"
                name="image"
            >
            @error('image')
                <div class="invalid-feedback">
                    {{ $message }} which is either png or jpeg
                </div>
            @enderror
        </div>
        <div>
            <div>Select labels</div>
            @foreach ($labels as $label)
                @if (isset($item) && $item->labels->contains($label))
                    <label><input type="checkbox" value="{{$label->id}}" name="label[] " checked>{{$label->name}}</label>
                @else
                    <label><input type="checkbox" value="{{$label->id}}" name="label[] ">{{$label->name}}</label>
                @endif
            @endforeach
        </div>
        <div class="row">
            <button type="submit" class="btn btn-primary">Save</button>
        </div>
    </form>
@endsection
