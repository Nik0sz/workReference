<?php

namespace Database\Seeders;

use App\Models\Item;
use App\Models\Label;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class LabelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = Item::all();
        foreach ($items as $item){
            $unlabeledItem = $items->where('id', '!=', $item->id)->random(7);
            Label::factory()
                ->hasAttached($unlabeledItem)->create();
        }
        Label::factory(3)->create();
    }
}
