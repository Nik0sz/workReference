<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $password = password_hash("adminpwd", PASSWORD_DEFAULT);
        User::factory()->create([
            'name' => 'Admin',
            'email' => 'admin@szerveroldali.hu',
            'password' => $password,
            'is_admin' => true,
        ]);

        $password = password_hash("password", PASSWORD_DEFAULT);
        for($i=2;$i<40;$i++){
            User::factory()->create([
                'email' => 'user'.$i.'@szerveroldali.hu',
                'password' => $password,
            ]);
        }
    }
}
