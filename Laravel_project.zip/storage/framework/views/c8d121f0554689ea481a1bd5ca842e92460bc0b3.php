<?php $__env->startSection('title', 'Item Detail'); ?>

<?php $__env->startSection('d_content'); ?>
    <button onclick="window.location.href='<?php echo e(route('items.index')); ?>'">Main Page</button>
    <div>
        <table class="table align-middle">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Obtained</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <img src=<?php echo e($item->image); ?> alt="">
                        <img src="<?php echo e(Illuminate\Support\Facades\Storage::url($item->image)); ?>" alt="" title="" />
                    </td>
                    <td>
                        <div><?php echo e($item->name); ?></div>
                    </td>
                    <td>
                        <div><?php echo e($item->description); ?></div>
                    </td>
                    <td>
                        <div><?php echo e($item->obtained); ?></div>
                    </td>
                    <td>
                        <a class="btn btn-outline-secondary" href="<?php echo e(route('items.edit', ['item' => $item->id])); ?>">Edit</a>
                        
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('labels'); ?>
    <div>
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <?php $__currentLoopData = $item->labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($label->display): ?>
                <?php $c = $label->color ?>
                    <li style="background-color:<?=$c?>"><?php echo e($label->name); ?></li>
                    <?php if(Auth::user()->is_admin): ?>
                        <li style="background-color:<?=$c?>"><a class="btn btn-outline-secondary" href="<?php echo e(route('labels.edit', ['label' => $label->id])); ?>">Edit</a></li>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('comments'); ?>
    <div>
        <?php if(is_null($item->comments)): ?>
            <div>No comments</div>
        <?php else: ?>
            <?php $__currentLoopData = $item->comments->sortBy('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3">
                    <div class="card-header d-flex">
                        <div class="me-auto"><span class="badge bg-secondary">#<?php echo e($loop->index); ?></span> | <strong><?php echo e($comment->user->name); ?></strong> | <?php echo e($comment->created_at); ?></div>
                    </div>
                    <div class="card-body">
                        <?php echo e($comment->text); ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_detailed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\denkl\OneDrive\Asztali gép\ELTE\Szerveroldali webprog\laravel\bead\resources\views/site/details.blade.php ENDPATH**/ ?>