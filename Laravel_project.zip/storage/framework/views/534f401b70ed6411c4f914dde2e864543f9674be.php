<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Muzeum | <?php echo $__env->yieldContent('title'); ?></title>
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
        crossorigin="anonymous"
    />
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
        integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg=="
        crossorigin="anonymous"
        referrerpolicy="no-referrer"
    />
</head>
<body class="bg-transparent">
    <div class="d-flex float-end">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <?php if(auth()->guard()->check()): ?>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>

                    <button onclick="event.preventDefault(); this.closest('form').submit();" window.location.href='<?php echo e(route('login')); ?>'>Logout</button>
                </form>
            <?php else: ?>
                <li class="nav-item">
                    
                    <button onclick="window.location.href='<?php echo e(route('login')); ?>'">Login</button>
                </li>
                <li class="nav-item">
                    
                    <button onclick="window.location.href='<?php echo e(route('register')); ?>'">Register</button>
                </li>
            <?php endif; ?>
        </ul>
    </div>
    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>
<?php /**PATH C:\Users\denkl\OneDrive\Asztali gép\ELTE\Szerveroldali webprog\laravel\bead\resources\views/layouts/flayout.blade.php ENDPATH**/ ?>