<?php $__env->startSection('title', 'Open Items'); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <?php if($user->name == "Admin"): ?>
            <button onclick="window.location.href='<?php echo e(route('items.create')); ?>'">Add new item</button>
            <button onclick="window.location.href='<?php echo e(route('labels.create')); ?>'">Add new label</button>
            
        <?php endif; ?>
    </div>
    <div>
        <table class="table align-middle">
            <thead>
                <tr>
                    <th scope="col">Image</th>
                    <th scope="col">Name</th>
                    <th scope="col">Description</th>
                    <th scope="col">More Info</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <img src=<?php echo e($item->image); ?> alt="">
                            <img src="<?php echo e(Illuminate\Support\Facades\Storage::url($item->image)); ?>" alt="" title="" />
                        </td>
                        <td>
                            <div><?php echo e($item->name); ?></div>
                        </td>
                        <td>
                            <div><?php echo e(substr(($item->description), 0, 50)); ?>...</div>
                        </td>
                        <td>
                            <a class="btn btn-outline-secondary" href="<?php echo e(route('items.show', ['item' => $item->id])); ?>">Details</a>
                            
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($items->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\denkl\OneDrive\Asztali gép\ELTE\Szerveroldali webprog\laravel\bead\resources\views/site/logged.blade.php ENDPATH**/ ?>