import {
  Box,
  Button,
  ButtonGroup,
  Flex,
  HStack,
  IconButton,
  Input,
  SkeletonText,
  Text,
  Select,
} from '@chakra-ui/react'
import { FaLocationArrow, FaTimes } from 'react-icons/fa'

import {
  useJsApiLoader,
  GoogleMap,
  Marker,
  Autocomplete,
  DirectionsRenderer,
} from '@react-google-maps/api'
import { useEffect, useRef, useState } from 'react'
import { Journey } from './Journey';

const center = {
  lat: 46.77430453872927,
  lng: 17.249055314015013,
};

const googleMapsApiKey = 'AIzaSyBrUj8PE3unbgpDxpnWWbrPYOpTFSRoDDs'; // Replace with your API key
const libraries = ['places'];



export function Directions() {
  const [map, setMap] = useState(null);
  const [directionsResponse, setDirectionsResponse] = useState(null);
  const [directionR, setDirectionR] = useState(null);
  const [distance, setDistance] = useState('');
  const [duration, setDuration] = useState('');
  const [travelMode_, setTravelMode] = useState('DRIVING');
  const [journeys, setJourneys] = useState([]);
  const [selectedJourneyIndex, setSelectedJourneyIndex] = useState(null);
  const [canTravel, setCanTravel] = useState(true);
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);


  const originRef = useRef();
  const destiantionRef = useRef();

  // Move the useJsApiLoader hook inside the component
  const { isLoaded } = useJsApiLoader({
    googleMapsApiKey: googleMapsApiKey,
    libraries: libraries,
  });


  useEffect(() => {
    const handleWindowResize = () => {
      setWindowWidth(window.innerWidth);
    };

    window.addEventListener('resize', handleWindowResize);

    return () => {
      window.removeEventListener('resize', handleWindowResize);
    };
  }, [windowWidth]);



  if (!isLoaded) {
    return null;
  }

  const calculateRoute = async () => {
    if (originRef.current.value === '' || destiantionRef.current.value === '') {
      return;
    }

    const directionsService = new window.google.maps.DirectionsService();
    let results;
    try {
      results = await directionsService.route({
        origin: originRef.current.value,
        destination: destiantionRef.current.value,
        travelMode: travelMode_,
        provideRouteAlternatives: true,
      });
      setCanTravel(true)
    } catch (error) {
      setCanTravel(false)
      setDirectionsResponse(null);
      setDistance('')
      setDuration('')
      console.log(error);
    }
    setDirectionsResponse(results);
    setDistance(results.routes[0].legs[0].distance.text)
    setDuration(results.routes[0].legs[0].duration.text)

    if (results) {
      const newJourneys = results.routes.map((route, index) => ({
        index: index + 1,
        distance: route.legs[0].distance.text,
        duration: route.legs[0].duration.text,
        steps: route.legs[0].steps,
      }));

      setJourneys(newJourneys);
    }
    setSelectedJourneyIndex(0);
    setDirectionR(null);
  };

  const selectJourney = (index) => {
    setSelectedJourneyIndex(index);
    // Render the selected route on the map
    if (directionsResponse) {
      const selectedRoute = directionsResponse.routes[index];
      setDistance(selectedRoute.legs[0].distance.text);
      setDuration(selectedRoute.legs[0].duration.text);

      // Update directionsResponse with the selected route
      setDirectionR({
        ...directionsResponse,
        routes: [selectedRoute],
      });
    }
  };

  const clearRoute = () => {
    setDirectionsResponse(null);
    setDistance('');
    setDuration('');
    originRef.current.value = '';
    destiantionRef.current.value = '';
    setSelectedJourney(null); // Clear the selected journey
  };

  const getCurrentLocation = (fieldRef) => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          fieldRef.current.value = `${latitude}, ${longitude}`;
        },
        (error) => {
          console.error('Error getting current location:', error);
        }
      );
    } else {
      console.error('Geolocation is not supported by this browser.');
    }
  };



  return (
    <Flex position='relative' flexDirection='column' alignItems='center'>
      <Box
        p={4}
        borderRadius='lg'
        m={4}
        bgColor='white'
        shadow='base'
        minW='container.md'
        zIndex='1'
      >
        <HStack spacing={2} justifyContent='space-between' flexDirection={windowWidth > 810 ? "row" : "column"}>
          <Box flexGrow={1}>
            <Autocomplete>
              <Input
                type='text'
                placeholder='Origin'
                ref={originRef}
              />
            </Autocomplete>

          </Box>
          <Box>

            <IconButton
              aria-label='Use current location for Origin'
              icon={<FaLocationArrow />}
              onClick={() => getCurrentLocation(originRef)}
            />
          </Box>
          <Box flexGrow={1}>
            <Autocomplete>
              <Input
                type='text'
                placeholder='Destination'
                ref={destiantionRef}
              />
            </Autocomplete>

          </Box>
          <Box>
            <IconButton
              aria-label='Use current location for Destination'
              icon={<FaLocationArrow />}
              onClick={() => getCurrentLocation(destiantionRef)}
            />
          </Box>
          <Box flexGrow={1}>
            <Select
              placeholder='Select travel mode'
              value={travelMode_}
              onChange={(e) => setTravelMode(e.target.value)}
            >
              <option value='DRIVING'>Driving</option>
              <option value='TRANSIT'>Public Transport</option>
              <option value='WALKING'>Walking</option>
            </Select>
          </Box>

          <ButtonGroup>
            <Button colorScheme='pink' type='submit' onClick={calculateRoute}>
              Calculate Route
            </Button>
            <IconButton
              aria-label='center back'
              icon={<FaTimes />}
              onClick={clearRoute}
            />
          </ButtonGroup>
        </HStack>
        <HStack spacing={4} mt={4} justifyContent='space-between'>
          <Text>Distance: {distance} </Text>
          <Text>Duration: {duration} </Text>
          <IconButton
            aria-label='center back'
            icon={<FaLocationArrow />}
            isRound
            onClick={() => {
              map.panTo(center);
              map.setZoom(15);
            }}
          />
        </HStack>
      </Box>
      <Box h='100%' w='100%'>
        <GoogleMap
          center={center}
          zoom={15}
          mapContainerStyle={{ width: '100%', height: '400px' }}
          options={{
            zoomControl: false,
            streetViewControl: false,
            mapTypeControl: false,
            fullscreenControl: false,
          }}
          onLoad={(map) => setMap(map)}
        >
          <Marker position={center} />
          {(directionR || directionsResponse) && (
            <DirectionsRenderer
              directions={directionR || directionsResponse}
            />
          )}
        </GoogleMap>
      </Box>

      {!canTravel && (
        <Box mt={4}>
          <div className="p-3 mb-2 bg-warning text-dark">
            The application cannot plan your route for this journey,<br /> it may involve travelling overseas, using planes or boats, or simply the the destination is unreachable or non exitent
          </div>
        </Box>
      )}
      {(journeys.length > 0 && canTravel) && (
        <Box mt={4}>
          <h2>Matching Journeys:</h2>
          <ul className="list-unstyled">
            {journeys.map((journey, index) => (
              <Journey
                key={index}
                journey={journey}
                onSelect={() => selectJourney(index)}
                isSelected={selectedJourneyIndex === index}
              />
            ))}
          </ul>
        </Box>
      )}
    </Flex>
  );
}