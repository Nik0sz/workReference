import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { selectLoggedInUser } from "./state/authSlice";
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';

export const NavbarComponent = () => {
  const loggedInUser = useSelector(selectLoggedInUser);
  const renderNavContent = () => {
    if (loggedInUser) {
      return (
        <>
          <Navbar expand="lg" className="bg-body-tertiary" style={{ justifyContent: "center", display: "flex", border: "1px solid #ddd" }}>
            <Container style={{ maxWidth: "700px" }}>
              <Navbar.Brand as={Link} to="/">Home page</Navbar.Brand>
              <Navbar.Toggle aria-controls="basic-navbar-nav" />
              <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="me-auto">
                  <Nav.Link as={Link} to="/directions">Search Route</Nav.Link>
                  <Nav.Link as={Link} to="/searchVehicle">Search Vehicle</Nav.Link>
                  <Nav.Link as={Link} to="/searchStop">Search By Stop</Nav.Link>
                  <Nav.Link as={Link} to="/favourite">Favourites</Nav.Link>
                  <Nav.Link as={Link} to="/logout">Logout</Nav.Link>
                </Nav>
              </Navbar.Collapse>
            </Container>
          </Navbar>
        </>
      )
    } else {
      return (
        <>
          <Navbar expand="lg" className="bg-body-tertiary" style={{ justifyContent: "center", display: "flex", border: "1px solid #ddd" }}>
            <Container style={{ maxWidth: "700px" }}>
              <Navbar.Brand as={Link} to="/">Home page</Navbar.Brand>
              <Navbar.Toggle aria-controls="basic-navbar-nav" />
              <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="me-auto">
                  <Nav.Link as={Link} to="/directions">Search Route</Nav.Link>
                  <Nav.Link as={Link} to="/searchVehicle">Search Vehicle</Nav.Link>
                  <Nav.Link as={Link} to="/searchStop">Search By Stop</Nav.Link>
                  <Nav.Link as={Link} to="/login">Login</Nav.Link>
                  <Nav.Link as={Link} to="/register">Register</Nav.Link>
                </Nav>
              </Navbar.Collapse>
            </Container>
          </Navbar>

        </>
      )
    }
  };

  return <div>{renderNavContent()}</div>;
};
// <div className="table-container">
//   <table className="table" >
//     <thead>
//       <tr>
//         <th className="nav-item">
//           <Link to="/" className="nav-link">Home page</Link>
//         </th>
//         <th className="nav-item">
//           <Link to="/directions" className="nav-link">Search Route</Link>
//         </th>
//         <th className="nav-item">
//           <Link to="/searchVehicle" className="nav-link">Search Vehicle</Link>
//         </th>
//         <th className="nav-item">
//           <Link to="/searchStop" className="nav-link">Search Stop</Link>
//         </th>
//         <th className="nav-item">
//           <Link to="/favourite" className="nav-link">Favourites</Link>
//         </th>
//         <th className="nav-item">
//           <Link to="/logout" className="nav-link">Logout</Link>
//         </th>
//       </tr>
//     </thead>
//   </table>
// </div>
{/* <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th className="nav-item">
                    <Link to="/" className="nav-link">Home page</Link>
                  </th>
                  <th className="nav-item">
                    <Link to="/directions" className="nav-link">Search Route</Link>
                  </th>
                  <th className="nav-item">
                    <Link to="/searchVehicle" className="nav-link">Search Vehicle</Link>
                  </th>
                  <th className="nav-item">
                    <Link to="/searchStop" className="nav-link">Search Stop</Link>
                  </th>
                  <th className="nav-item">
                    <Link to="/login" className="nav-link">Login</Link>
                  </th>
                  <th className="nav-item">
                    <Link to="/register" className="nav-link">Register</Link>
                  </th>
                </tr>
              </thead>
            </table>
          </div> */}