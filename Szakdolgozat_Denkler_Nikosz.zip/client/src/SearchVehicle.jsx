import React, { useState, useEffect } from 'react';
import { Route } from './Route';


export function SearchVehicle() {
  const [vehicle, setVehicle] = useState('');
  const [provider, setProvider] = useState('budapest');
  const [matchingRoutes, setMatchingRoutes] = useState([]);
  const [stat, setStatus] = useState('');


  const handleInputChange = (event) => {
    setVehicle(event.target.value);
  };

  const handleProviderChange = (event) => {
    setProvider(event.target.value);
  };

  const isButtonDisabled = vehicle.trim() === '';

  const handleSearch = async (event) => {
    // let c = count;
    // c++;
    // setCount(c)
    event.preventDefault();
    try {
      const response = await fetch(`http://localhost:3000/searchVehicle?provider=${provider}&vehicle=${vehicle}`);
      console.log(response);
      if (response.ok) {
        setStatus('');
        const data = await response.json();
        const dataArray = Object.values(data);

        setMatchingRoutes(dataArray);
      } else {
        setStatus(response.status)
        console.error(`Error fetching dataArray: ${response.status} - ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const noMatch = () => {
    if(stat == '404'){
      let actProv;
      if(provider == "budapest"){
        actProv = "BKK"
      }else if(provider == "mav"){
        actProv = "MAV"
      }else if(provider == "volanbusz"){
        actProv = "VOLANBUSZ"
      }
      return(
        <div>
            {actProv} doesn't have an existing vehicle with the entered name
        </div>
      )
    }
  }

  return (
    <div>
      <h1>Search Vehicles by Name</h1>
      <form id="searchForm" onSubmit={handleSearch}>
        <label htmlFor="provider">Select Provider:</label>
        <select
          id="provider"
          name="provider"
          value={provider}
          onChange={handleProviderChange}
        >
          <option value="budapest">BKK</option>
          <option value="mav">MÁV</option>
          <option value="volanbusz">Volánbusz</option>
        </select>
        <br />
        <label htmlFor="vehicle">Vehicle:</label>
        <input
          type="text"
          id="vehicle"
          name="vehicle"
          value={vehicle}
          onChange={handleInputChange}
        />
        <br />
        <button type="submit" id="searchButton" disabled={isButtonDisabled}>
          Search
        </button>
      </form>
      <div className='1rem'>
        {(matchingRoutes.length > 0 && stat != "404") &&  (
          <div>
            <h2>Matching Vehicle Names:</h2>
            <ul className="list-unstyled">
              {matchingRoutes.slice(0, 100).map((route, index) => (
                <Route key={index} route={route} parent='vehicle' />
              ))}
            </ul>
          </div>
        )}
        {noMatch()}
      </div>
    </div>
  );
}
