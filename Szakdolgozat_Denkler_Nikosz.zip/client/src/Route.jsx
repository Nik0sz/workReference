import { useSelector } from "react-redux";
import { selectLoggedInUser, } from "./state/authSlice";
import React, { useState } from 'react';

export function Route({ route, parent, refresh }) {
  const user = useSelector(selectLoggedInUser);
  const [isFavorite, setIsFavorite] = useState(false);

  const checkFavoriteStatus = async () => {
    try {
      const response = await fetch(`http://localhost:3000/checkFavourite?user=${user}&routeId=${route.route_id}`);
      if (response.ok) {
        const data = await response.json();
        setIsFavorite(data.isFavorite);
      } else {
        console.error(`Error checking favorite status: ${response.status} - ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error checking favorite status:', error);
    }
  };

  const handleAddToFavorites = async () => {
    try {
      const response = await fetch(`http://localhost:3000/addFavourite?user=${user}&routeId=${route.route_id}&agencyId=${route.agency_id}&route_short_name=${route.route_short_name}&route_long_name=${route.route_long_name}`, {
        method: 'POST',
      });
      if (response.ok) {
        setIsFavorite(true);
        // Handle success (maybe show a success message)
      } else {
        console.error(`Error adding to favorites: ${response.status} - ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error adding to favorites:', error);
    }
  };

  const handleRemoveFromFavorites = async () => {
    try {
      const response = await fetch(`http://localhost:3000/removeFavorite?user=${user}&routeId=${route.route_id}`, {
        method: 'DELETE', // Since your server is expecting a DELETE request
      });

      if (response.ok) {
        setIsFavorite(false);
        refresh();
        // Handle success (maybe show a success message)
      } else {
        console.error(`Error removing from favorites: ${response.status} - ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error removing from favorites:', error);
    }
  };


  const renderButton = () => {
    if (parent == 'favourite') {
      return (
        <button className='btn btn-warning' onClick={handleRemoveFromFavorites}>
          Remove from Favorites
        </button>
      );
    } else if (parent == 'vehicle') {
      checkFavoriteStatus();
      if (isFavorite) {
        return (
          <div>
            The route is already a favourite
          </div>
        )
      }
      return (
        <button className='btn btn-outline-warning' onClick={handleAddToFavorites}>
          Add to Favorites
        </button>
      );
    }
  };

  const renderLink = () => {
    if (route.agency_id == 'BKK' || route.agency_id == 'HEV') {
      return(
        <a href="https://bkk.hu/jegyek-es-berletek/">BKK</a>
      )
    } else if (route.agency_id == '198' || route.agency_id == '134' || route.agency_id == '202' || route.agency_id == '140') {
      return(
        <a href="https://jegy.mav.hu/">MAV</a>
      )
    } else {
      return(
        <a href="https://www.volanbusz.hu/hu/jegy-es-berlet">VOLANBUSZ</a>
      )
    }
  };


  return (
    <li className="route-container">
      <div>
        Agency ID: {route.agency_id}
      </div>
      <div>
        Route ID: {route.route_id}
      </div>
      <div>
        {route.route_short_name && (
          <>
            {' Vehicle\'s name: '}
            {route.route_short_name}
            <br />
          </>
        )}
        {route.route_long_name && (
          <>
            {' Vehicle\'s long Name: '}
            {route.route_long_name}
          </>
        )}
      </div>
      {renderLink()}
      {user && <br />}
      {user && renderButton()}
    </li>
  );
}
