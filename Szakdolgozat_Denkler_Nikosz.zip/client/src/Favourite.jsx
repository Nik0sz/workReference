import React, { useState, useEffect } from 'react';
import { useSelector } from "react-redux";
import { selectLoggedInUser, } from "./state/authSlice";
import { Route } from './Route';

export function Favourite() {
  const [favoriteRoutes, setFavoriteRoutes] = useState([]);
  const user = useSelector(selectLoggedInUser);
  
  const fetchFavorites = async () => {
    try {
      const response = await fetch(`http://localhost:3000/getFavorites?user=${user}`);
      if (response.ok) {
        const data = await response.json();
        setFavoriteRoutes(data);
      } else {
        console.error(`Error fetching favorites: ${response.status} - ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error fetching favorites:', error);
    }
  };

  useEffect(() => {
    fetchFavorites();
  }, []);

  const refreshFavourites = async () => {
    try {
      fetchFavorites();      
    } catch (error) {
      console.error('Error fetching favorites:', error);
    }
  }

  return (
    <div>
      <h1>Your Saved Routes</h1>
      <ul className="list-unstyled">
        {favoriteRoutes.map((route, index) => (
          <Route key={index} route={route} parent='favourite' refresh={refreshFavourites}/>
        ))}
      </ul>
    </div>
  );
}
