import React from 'react';

export function Journey({ journey, onSelect, isSelected }) {
  const writeName = (step) => {
    if (step.travel_mode === "TRANSIT" && step.transit && step.transit.line) {
      if(step.transit.line.name){
        return step.transit.line.name;
      }else{
        return step.transit.line.short_name;
      }
    }
    return null;
  }

  const renderSteps = () => {
    return (
      <ol>
        {journey.steps.map((step, index) => (
          <li key={index}>
            <span dangerouslySetInnerHTML={{ __html: step.instructions }} />
            {step.travel_mode === "TRANSIT" && (
              <span>, name of the vehicle: {writeName(step)}</span>
            )}
          </li>
        ))}
      </ol>
    );
  };

  return (
    <li
      className={`route-container ${isSelected ? 'selected' : ''}`}
      onClick={onSelect} // Invoke the onSelect function when the Journey is clicked
      style={{ background: isSelected ? '#4285F4' : 'transparent', color: isSelected ? 'white' : 'inherit' }}
    >
      <div>Possible journeys, number: {journey.index}</div>
      <div>Distance: {journey.distance}</div>
      <div>Duration: {journey.duration}</div>
      <div>
        Steps: {renderSteps()}
      </div>
    </li>
  );
}
