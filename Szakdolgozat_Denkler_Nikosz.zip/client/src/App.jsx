import './App.css'
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Layout } from './Layout';
import { Login } from "./Login";
import { Logout } from "./Logout";
import { Registration } from "./Registration";
import { HomePage } from './HomePage';
import { LoggedIn } from "./LoggedIn"
import { SearchVehicle } from './SearchVehicle';
import { SearchStop } from './SearchStop';
import { Favourite } from './Favourite';
import { Directions } from './Directions';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route
            path='/'
            element={
              <HomePage />
            }
          />
          <Route 
            path="/login"
            element={
              <Login />
            } 
          />
          <Route 
            path="/register"
            element={
              <Registration />
            }
          />
          <Route 
            path="/logout"
            element={
              <LoggedIn>
                <Logout />
              </LoggedIn>
            }
          />
          <Route
            path='/directions'
            element={
              <Directions />
            }
          />
          <Route
            path="/searchStop"
            element={
              <SearchStop />
            } 
          />
          <Route
            path="/searchVehicle"
            element={
              <SearchVehicle />
            } 
          />
          <Route
            path="/favourite"
            element={
              <LoggedIn>
                <Favourite />
              </LoggedIn>
            }
          />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App
