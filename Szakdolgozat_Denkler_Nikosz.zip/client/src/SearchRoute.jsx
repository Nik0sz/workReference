// import React, { useState } from 'react';

// export function SearchRoute() {
//   const [from, setFrom] = useState('');
//   const [to, setTo] = useState('');

//   const handleInputChange = (event) => {
//     const { name, value } = event.target;
//     name === 'from' ? setFrom(value) : setTo(value);
//   };

//   const isButtonDisabled = from.trim() === '' || to.trim() === '';

//   return (
//     <div>
//       <h1>Search plans :D</h1>
//       <p>This is the search route content.</p>
//       <form id="searchForm">
//         <label htmlFor="from">From:</label>
//         <input
//           type="text"
//           id="from"
//           name="from"
//           value={from}
//           onChange={handleInputChange}
//         />
//         <label htmlFor="to">To:</label>
//         <input
//           type="text"
//           id="to"
//           name="to"
//           value={to}
//           onChange={handleInputChange}
//         />
//         <button type="submit" id="searchButton" disabled={isButtonDisabled}>
//           Search
//         </button>
//       </form>
//     </div>
//   );
// }
import React, { useState } from 'react';

export function SearchRoute() {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [provider, setProvider] = useState('budapest');
  const [plans, setPlans] = useState([]);


  const handleFromChange = (event) => {
    setFrom(event.target.value);
  };

  const handleToChange = (event) => {
    setTo(event.target.value);
  }

  const handleProviderChange = (event) => {
    setProvider(event.target.value);
  };

  const isButtonDisabled = from.trim() === '' || to.trim() === '';

  const handleSearch = async (event) => {
    event.preventDefault();

    try {
      const response = await fetch(`http://localhost:3000/searchRoute?provider=${provider}&from=${from}&to=${to}`);

      if (response.ok) {
        const data = await response.json();
        console.log(data);
        setPlans(data);
      } else {
        console.error(`Error fetching data: ${response.status} - ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div>
      <h1>Search Routes</h1>
      <form onSubmit={handleSearch}>
        <label htmlFor="provider">Select Provider:</label>
        <select
          id="provider"
          name="provider"
          value={provider}
          onChange={handleProviderChange}
        >
          <option value="budapest">BKK</option>
          <option value="mav">MÁV</option>
          <option value="volanbusz">Volánbusz</option>
        </select>
        <label htmlFor="from">From:</label>
        <input
          type="text"
          id="from"
          name="from"
          value={from}
          onChange={handleFromChange}
        />
        <label htmlFor="to">To:</label>
        <input
          type="text"
          id="to"
          name="to"
          value={to}
          onChange={handleToChange}
        />
        <button type="submit" disabled={isButtonDisabled}>
          Search
        </button>
      </form>
      <div>
        {plans.length > 0 && (
          <div>
            <h2>Possible Routes:</h2>
            <ul className="list-unstyled">
              {plans.map((plan, index) => (
                <li key={index}>
                  Route ID: {plan.route_id}, Route Name: {plan.route_name}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}


import {
  Box,
  Button,
  ButtonGroup,
  Flex,
  HStack,
  IconButton,
  Input,
  SkeletonText,
  Text,
  Select,
} from '@chakra-ui/react'
import { FaLocationArrow, FaTimes } from 'react-icons/fa'

import {
  useJsApiLoader,
  GoogleMap,
  Marker,
  Autocomplete,
  DirectionsRenderer,
} from '@react-google-maps/api'
import { useRef, useState, useEffect } from 'react'
import { Journey } from './Journey';

const center = {
  lat: 46.77430453872927,
  lng: 17.249055314015013,
};

const googleMapsApiKey = 'AIzaSyBrUj8PE3unbgpDxpnWWbrPYOpTFSRoDDs';

const libraries = ['places'];

export function Directions() {
  const { isLoaded } = useJsApiLoader({
    googleMapsApiKey: googleMapsApiKey,
    libraries: libraries,
  })

  const [map, setMap] = useState(/** @type google.maps.Map */(null))
  const [directionsResponse, setDirectionsResponse] = useState(null)
  const [distance, setDistance] = useState('')
  const [duration, setDuration] = useState('')
  const [journeys, setJourneys] = useState([]);
  const [travelMode_, setTravelMode] = useState('DRIVING')

  const originRef = useRef()
  const destiantionRef = useRef()

  if (!isLoaded) {
    return null;
  }

  async function calculateRoute() {
    if (originRef.current.value === '' || destiantionRef.current.value === '') {
      return;
    }

    setDirectionsResponse(null);

    const directionsService = new google.maps.DirectionsService();
    const results = await directionsService.route({
      origin: originRef.current.value,
      destination: destiantionRef.current.value,
      travelMode: travelMode_,
      provideRouteAlternatives: true,
    });

    setDirectionsResponse(results);
    setDistance(results.routes[0].legs[0].distance.text)
    setDuration(results.routes[0].legs[0].duration.text)
    if (results) {
      const newJourneys = results.routes.map((route, index) => ({
        index: index + 1,
        distance: route.legs[0].distance.text,
        duration: route.legs[0].duration.text,
        steps: route.legs[0].steps,
      }));
      results.routes.forEach((route, index) => {
        console.log(`Route ${index + 1}:`);
        console.log('Distance:', route.legs[0].distance.text);
        console.log('Duration:', route.legs[0].duration.text);
        console.log('Steps:', route.legs[0].steps);

      });

      setJourneys(newJourneys);
    }
  }

  function clearRoute() {
    setDirectionsResponse(null)
    setDistance('')
    setDuration('')
    originRef.current.value = ''
    destiantionRef.current.value = ''
  }

  return (
    <Flex
      position='relative'
      flexDirection='column'
      alignItems='center'
    //h='100vh'
    //w='100vw'
    //mt='4'
    >

      <Box
        p={4}
        borderRadius='lg'
        m={4}
        bgColor='white'
        shadow='base'
        minW='container.md'
        zIndex='1'
      >
        <HStack spacing={2} justifyContent='space-between'>
          <Box flexGrow={1}>
            <Autocomplete>
              <Input type='text' placeholder='Origin' ref={originRef} />
            </Autocomplete>
          </Box>
          <Box flexGrow={1}>
            <Autocomplete>
              <Input
                type='text'
                placeholder='Destination'
                ref={destiantionRef}
              />
            </Autocomplete>
          </Box>
          <Box flexGrow={1}>
            <Select
              placeholder='Select travel mode'
              value={travelMode_}
              onChange={(e) => setTravelMode(e.target.value)}
            >
              <option value='DRIVING'>Driving</option>
              <option value='TRANSIT'>Public Transport</option>
              <option value='WALKING'>Walking</option>
            </Select>
          </Box>

          <ButtonGroup>
            <Button colorScheme='pink' type='submit' onClick={calculateRoute}>
              Calculate Route
            </Button>
            <IconButton
              aria-label='center back'
              icon={<FaTimes />}
              onClick={clearRoute}
            />
          </ButtonGroup>
        </HStack>
        <HStack spacing={4} mt={4} justifyContent='space-between'>
          <Text>Distance: {distance} </Text>
          <Text>Duration: {duration} </Text>
          <IconButton
            aria-label='center back'
            icon={<FaLocationArrow />}
            isRound
            onClick={() => {
              map.panTo(center)
              map.setZoom(15)
            }}
          />
        </HStack>
      </Box>
      <Box h='100%' w='100%'>
        <GoogleMap
          center={center}
          zoom={15}
          mapContainerStyle={{ width: '100%', height: '400px' }}
          options={{
            zoomControl: false,
            streetViewControl: false,
            mapTypeControl: false,
            fullscreenControl: false,
          }}
          onLoad={map => setMap(map)}
        >
          <Marker position={center} />
          {directionsResponse && (
            <DirectionsRenderer directions={directionsResponse} />
          )}
        </GoogleMap>
      </Box>
      {journeys.length > 0 && (
        <Box mt={4}>
          <h2>Matching Journeys:</h2>
          <ul className="list-unstyled">
            {journeys.map((journey) => (
              <Journey key={journey.index} journey={journey} />
            ))}
          </ul>
        </Box>
      )}
    </Flex>
  )
}