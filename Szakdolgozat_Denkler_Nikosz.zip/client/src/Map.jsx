import React, { useEffect, useState } from 'react';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';

const libraries = ['places'];

export function Map() {
  const [searchQuery, setSearchQuery] = useState('');
  const [map, setMap] = useState(null);
  const [placesService, setPlacesService] = useState(null);

  const mapContainerStyle = {
    width: '100%',
    height: '400px',
  };

  const center = {
    lat: 46.77430453872927,
    lng: 17.249055314015013,
  };

  const onLoad = (map) => {
    setMap(map);
  };

  const onPlacesServiceLoad = (service) => {
    setPlacesService(service);
  };

  const handleSearch = () => {
    if (!map || !placesService) return;

    var request = {
      query: searchQuery,
      fields: ['name', 'geometry'],
    };

    placesService.textSearch(request, function (results, status) {
      if (status === window.google.maps.places.PlacesServiceStatus.OK) {
        map.setCenter(results[0].geometry.location);
      }
    });
  };

  return (
    <div className="content">
      <h1>Search in map :D</h1>
      <p>This is the search map content.</p>
      <div className="search-container">
        <input
          id="search-input"
          type="text"
          placeholder="Search for a place"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <button id="search-button" onClick={handleSearch}>
          Search
        </button>
      </div>
      <LoadScript googleMapsApiKey="AIzaSyBrUj8PE3unbgpDxpnWWbrPYOpTFSRoDDs" libraries={libraries}>
        <GoogleMap
          mapContainerStyle={mapContainerStyle}
          center={center}
          zoom={12}
          onLoad={onLoad}
        >
          {/* You can add markers or other map components here if needed */}
        </GoogleMap>
      </LoadScript>
    </div>
  );
};
