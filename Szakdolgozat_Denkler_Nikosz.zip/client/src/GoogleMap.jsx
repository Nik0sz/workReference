import React, { useEffect } from 'react';
import { GoogleMap, Marker, DirectionsRenderer } from '@react-google-maps/api';


function MapRenderer({ map, directionsResponse }) {
    useEffect(() => {
      if (map && directionsResponse === null) {
        const directionsRenderer = new google.maps.DirectionsRenderer();
        directionsRenderer.setMap(null);
      }
    }, [map, directionsResponse]);
  
    return (
      <>
        <GoogleMap
          center={center}
          zoom={15}
          mapContainerStyle={{ width: '100%', height: '400px' }}
          options={{
            zoomControl: false,
            streetViewControl: false,
            mapTypeControl: false,
            fullscreenControl: false,
          }}
          onLoad={map => setMap(map)}
        >
          <Marker position={center} />
          {directionsResponse && (
            <DirectionsRenderer directions={directionsResponse} />
          )}
        </GoogleMap>
      </>
    );
  }