import { NavbarComponent } from "./Navbar";
import { Outlet } from "react-router-dom";

export const Layout = () => {
  return (
    <>
      <NavbarComponent />
      <br /><br /><br />
      <Outlet />
    </>
  );
};