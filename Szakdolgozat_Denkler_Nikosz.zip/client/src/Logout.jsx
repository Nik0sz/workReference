import { useDispatch, useSelector } from "react-redux"
import { logout, selectLoggedInUser } from "./state/authSlice"

export const Logout = () => {
    const user = useSelector(selectLoggedInUser)
    const dispatch = useDispatch();

    if(user){
        return (
            <div>
                <button onClick={() => dispatch(logout()) }>Logout</button>
            </div>
        )
    }
}