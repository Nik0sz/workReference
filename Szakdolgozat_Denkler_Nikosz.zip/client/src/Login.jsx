import { useEffect, useRef } from "react";
import { useState } from "react";
import TextField from "@mui/material/TextField";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router";
import { login } from "./state/authSlice";
import axios from 'axios';

export const Login = () => {
  // State
  const [errors, setErrors] = useState({
    email: null,
    password: null,
  });
  const dispatch = useDispatch();
  const navigate = useNavigate();
  // Ref
  const emailRef = useRef();
  const passwordRef = useRef();


  axios.defaults.withCredentials = true;
  const handleSubmit = async (e) => {
    e.preventDefault();
    const email = emailRef.current.value;
    const password = passwordRef.current.value;
    const newErrors = {};

    if (email === "") {
      newErrors.email = "Username is required!";
    }
    if (password === "") {
      newErrors.password = "Password is required!";
    }
    setErrors(newErrors);
    console.log(newErrors.length);
    if (Object.keys(newErrors).length > 0) {
      return;
    }

    let values = [email, password]

    axios.post('http://localhost:3000/login', values)
      .then(res => {
        console.log(res.data);
        if (res.data.Status === "Success") {
          console.log(res.data);
          navigate('/')
          dispatch(
            login({
              user: res.data.name,
              token: res.data.token,
            })
          );
        } else {
          alert('Error')
        }
      })
      .catch(err => {
        const newErrors = {}
        if(err.response.data.Error == "An error occurred during login"){
          newErrors.email = "Invalid email!";
          setErrors(newErrors)
        }else if(err.response.data.Error == "Invalid credentials"){
          newErrors.password = "Invalid password!";
          setErrors(newErrors)
        }
        console.log(err)}
    );
    // try {
    //   let result = await fetch("http://localhost:3030/authentication", {
    //     method: "POST",
    //     body: JSON.stringify({
    //       email: email,
    //       password: password,
    //       strategy: "local",
    //     }),
    //     headers: {
    //       "Content-Type": "application/json"
    //     },
    //   })
    //   result = await result.json();
    //   dispatch(
    //     login({
    //       user: result.user,
    //       token: result.accessToken,
    //     })
    //   );
    //   if(result.code != 401){
    //     navigate("/", { replace: true });
    //   }
    // } catch (e) {
    //   console.log("Hibaaaaaaaaaaaaaa", e);
    //   newErrors.email = "Login failed!";
    //   setErrors(newErrors);
    // }
  };
  return (
    <>
      <h1>Login</h1>
      <form onSubmit={handleSubmit}>
        <TextField
          label="Username(email)"
          variant="outlined"
          name="email"
          defaultValue=""
          inputRef={emailRef}
          className={errors.email ? 'error' : ''}
          autoFocus
        />
        <br />
        {errors.email && <span>{errors.email}</span>}
        <br />
        <TextField
          type="password"
          label="Password"
          variant="outlined"
          name="password"
          inputRef={passwordRef}
          className={errors.password ? 'error' : ''}
        />
        <br />
        {errors.password && <span>{errors.password}</span>}
        <br />
        <button type="submit">Login</button>
      </form>
    </>
  );
};