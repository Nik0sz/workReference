import React, { useState, useEffect } from 'react';
import { Route } from './Route';


export function SearchStop() {
  const [stopName, setStopName] = useState('');
  const [provider, setProvider] = useState('budapest');
  const [matchingRoutes, setMatchingRoutes] = useState([]);
  //const [count, setCount] = useState(0);
  const [stat, setStatus] = useState('');

  // useEffect(() => {
  //   setCount(0);
  // }, []);

  const handleStopNameChange = (event) => {
    setStopName(event.target.value);
  };

  const handleProviderChange = (event) => {
    setProvider(event.target.value);
  };

  const isButtonDisabled = stopName.trim() === '';


  const handleSearch = async (event) => {
    // let c = count;
    // c++;
    // setCount(c)
    event.preventDefault();
    try {
      const response = await fetch(`http://localhost:3000/searchStop?provider=${provider}&stopName=${stopName}`);

      if (response.ok) {
        setStatus('');
        const data = await response.json();
        setMatchingRoutes(data);
      } else {
        setStatus(response.status)
        console.error(`Error fetching data: ${response.status} - ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const noMatch = () => {
    if(stat == '404'){
      let actProv;
      if(provider == "budapest"){
        actProv = "BKK"
      }else if(provider == "mav"){
        actProv = "MAV"
      }else if(provider == "volanbusz"){
        actProv = "VOLANBUSZ"
      }
      return(
        <div>
            {actProv} doesn't have an existing stop with the entered name
        </div>
      )
    }
  }

  return (
    <div>
      <h1>Search by Stop Name</h1>
      <form onSubmit={handleSearch}>
        <label htmlFor="provider">Select Provider:</label>
        <select
          id="provider"
          name="provider"
          value={provider}
          onChange={handleProviderChange}
        >
          <option value="budapest">BKK</option>
          <option value="mav">MÁV</option>
          <option value="volanbusz">Volánbusz</option>
        </select>
        <br />
        <label htmlFor="stopName">Stop Name:</label>
        <input
          type="text"
          id="stopName"
          name="stopName"
          value={stopName}
          onChange={handleStopNameChange}
        />
        <br />
        <button type="submit" disabled={isButtonDisabled}>
          Search
        </button>
      </form>
      <div className='1rem'>
        {(matchingRoutes.length > 0 && stat != "404") && (
          <div>
            <h2>Vehicles going through the searched stop</h2>
            <ul className="list-unstyled">
              {matchingRoutes.slice(0, 100).map((route, index) => (
                <Route key={index} route={route} parent='vehicle' />
              ))}
            </ul>
          </div>
        )}
        {noMatch()}
      </div>
    </div>
  );
}
