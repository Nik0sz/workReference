import { useRef, useState } from "react";
import { useNavigate } from "react-router";
import { TextField } from "@mui/material";
import axios from 'axios';

export const Registration = () => {
  const [errors, setErrors] = useState({
    name: null,
    email: null,
    password: null,
  });
  const navigate = useNavigate();

  const nameRef = useRef();
  const emailRef = useRef();
  const passwordRef = useRef();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const name = nameRef.current.value;
    const email = emailRef.current.value;
    const password = passwordRef.current.value;
    const newErrors = {};

    if (name === "") {
      newErrors.name = "Name is required!";
    }
    if (email === "") {
      newErrors.email = "Email is required!";
    } else if (!validateEmail(email)) {
      newErrors.email = "Invalid email format!";
    }
    if (password === "") {
      newErrors.password = "Password is required!";
    }
    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) {
      return;
    }

    let values = [name, email, password]

    axios.post('http://localhost:3000/register', values)
      .then(res => {
        if (res.data.Status === "Success") {
          navigate('/login')
        } else {
          alert('Error')
        }
      })
      .catch(err => {
        let newErrors = {}
        if (err.response.data.Error == "Username or email already exists") {
          console.log("asd");
          newErrors.name = "Username or email already exists"
          newErrors.email = "Username or email already exists"
          setErrors(newErrors);
        }
        console.log(err);

      })
    console.log(errors);

    // try {
    //   let result = await fetch("http://localhost:3030/users", {
    //     method: "POST",
    //     body: JSON.stringify({
    //       email: email,
    //       password: password,
    //       fullname: name,
    //     }),
    //     headers: {
    //       "Content-Type": "application/json"
    //     },
    //   })
    //   result = await result.json();
    //   dispatch(
    //     register({
    //       user: result.user,
    //       token: result.accessToken,
    //     })
    //   );
    //   if(result.code != 401){
    //     navigate("/", { replace: true });
    //   }
    // } catch (e) {
    //   console.log("Error", e);
    //   newErrors.email = "Registration failed!";
    //   setErrors(newErrors);
    // }
  };

  const validateEmail = (email) => {
    // Simple email validation using regular expression
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  return (
    <>
      <h1>Registration</h1>
      <form onSubmit={handleSubmit}>
        <TextField
          label="Name"
          variant="outlined"
          name="name"
          inputRef={nameRef}
          className={errors.name ? 'error' : ''}
          autoFocus
        />
        <br />
        {errors.name && <span>{errors.name}</span>}
        <br />
        <TextField
          label="Email"
          variant="outlined"
          name="email"
          inputRef={emailRef}
          className={errors.email ? 'error' : ''}
        />
        <br />
        {errors.email && <span>{errors.email}</span>}
        <br />
        <TextField
          type="password"
          label="Password"
          variant="outlined"
          name="password"
          inputRef={passwordRef}
          className={errors.password ? 'error' : ''}
        />
        <br />
        {errors.password && <span>{errors.password}</span>}
        <br />
        <button type="submit">Register</button>
      </form>
    </>
  );
};