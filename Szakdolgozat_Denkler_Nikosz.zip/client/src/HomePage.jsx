import React from 'react';

export const HomePage = () => {
  return (
    <div style={{ paddingRight: "4rem", paddingLeft: "4rem" }}>
      <div >
        <h2>🚌 Welcome to our web application</h2>
        <p>Discover the convenience of public transportation with it. We're here to make your daily commute a little smoother.</p>
      </div>

      <div >
        <h3>🗺️ Easy Navigation:</h3>
        <p>Find the quickest routes, check vehicle schedules, and locate stops effortlessly. The webapp is designed to be simple and user-friendly.</p>
      </div>

      <div >
        <h3>📍 Quick Search:</h3>
        <p>Looking for a specific vehicle or stop? Our search feature helps you find what you need in a snap.</p>
      </div>

      <div >
        <h3>🌟 Basic Personalization:</h3>
        <p>Create an account to save your favorite vehicles for a more personalized experience.</p>
      </div>
    </div>
  );
};