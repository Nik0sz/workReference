const fastify = require('fastify')({ logger: true });
const cors = require('@fastify/cors');
const db = require('./models');
const { Op } = require('sequelize');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const cookie = require('@fastify/cookie');
const salt = 10;

fastify.register(cookie);

fastify.addContentTypeParser('application/json', { parseAs: 'buffer' }, function (req, body, done) {
    try {
        const json = JSON.parse(body.toString());
        done(null, json);
    } catch (err) {
        err.statusCode = 400;
        done(err, undefined);
    }
});



fastify.register(cors, {
    origin: 'http://localhost:5173',
    methods: ["POST", "GET", "DELETE"],
    credentials: true,
});


fastify.post('/register', async (req, res) => {
    try {
        const existingUser = await db.sequelize.query(
            "SELECT * FROM users WHERE email = ? OR name = ?",
            {
                replacements: [req.body[1], req.body[0]],
                type: db.sequelize.QueryTypes.SELECT
            }
        );

        if (existingUser.length > 0) {
            return res.status(400).send({ Error: "Username or email already exists" });
        }

        const sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
        const hash = await bcrypt.hash(req.body[2], salt);

        const values = [
            req.body[0],
            req.body[1],
            hash
        ];

        const [results] = await db.sequelize.query(sql, {
            replacements: values,
            type: db.sequelize.QueryTypes.INSERT
        });

        return res.status(201).send({ Status: "Success" });
    } catch (err) {
        console.error('Error in /register:', err);
        return res.status(500).send({ Error: "An error occurred while registering" });
    }
});

fastify.post('/login', async (req, res) => {
    try {
        const sql = "SELECT * FROM users WHERE email = ?";
        const [data] = await db.sequelize.query(sql, {
            replacements: [req.body[0]],
            type: db.sequelize.QueryTypes.SELECT
        });

        const passwordMatch = await bcrypt.compare(req.body[1], data.password);

        if (passwordMatch) {
            const name = data.name;
            const token = jwt.sign({ name }, "very-big-secret", { expiresIn: '1d' })
            res.cookie('token', token);
            return res.status(200).send({ Status: "Success", name, token });
        }

        return res.status(401).send({ Error: "Invalid credentials" });
    } catch (err) {
        console.error('Error in /login:', err);
        return res.status(500).send({ Error: "An error occurred during login" });
    }
});


fastify.get('/searchVehicle', async (req, res) => {
    try {
        const provider = req.query.provider;
        const vehicle = req.query.vehicle;

        let routes;

        if (provider == 'budapest') {
            routes = await db.Budapest_routes.findAll({
                where: {
                    [Op.or]: [
                        { route_short_name: { [Op.like]: `%${vehicle}%` } },
                        { route_long_name: { [Op.like]: `%${vehicle}%` } }
                    ]
                }
            });
        } else if (provider == 'mav') {
            routes = await db.Mav_routes.findAll({
                where: {
                    [Op.or]: [
                        { route_short_name: { [Op.like]: `%${vehicle}%` } },
                        { route_long_name: { [Op.like]: `%${vehicle}%` } }
                    ]
                }
            });
        } else if (provider == 'volanbusz') {
            routes = await db.Volanbusz_routes.findAll({
                where: {
                    [Op.or]: [
                        { route_short_name: { [Op.like]: `%${vehicle}%` } },
                        { route_long_name: { [Op.like]: `%${vehicle}%` } }
                    ]
                }
            });
        } else {
            routes = []
        }

        if (routes && routes.length > 0) {
            return res.status(200).send(routes);
        } else {
            return res.status(404).send({ Error: "No routes found" });
        }
    } catch (error) {
        console.error('Error in /searchVehicle:', err);
        return res.status(500).send({ Error: "An error occurred while searching for vehicles" });
    }

});

fastify.get('/searchStop', async (req, res) => {
    try {
        const provider = req.query.provider;
        const stopName = req.query.stopName;

        let stops;
        let stopIds;
        let route_stop;
        let routeIds;
        let routes;

        if (provider === 'budapest') {
            stops = await db.Budapest_stops.findAll({ where: { stop_name: stopName } });
            stopIds = stops.map((stop) => stop.stop_id);
            route_stop = await db.Budapest_route_stop.findAll({ where: { stop_id: stopIds } });
            routeIds = route_stop.map((route_stop) => route_stop.route_id);
            routes = await db.Budapest_routes.findAll({ where: { route_id: routeIds } });
        } else if (provider === 'mav') {
            stops = await db.Mav_stops.findAll({ where: { stop_name: stopName } });
            stopIds = stops.map((stop) => stop.stop_id);
            route_stop = await db.Mav_route_stop.findAll({ where: { stop_id: stopIds } });
            routeIds = route_stop.map((route_stop) => route_stop.route_id);
            routes = await db.Mav_routes.findAll({ where: { route_id: routeIds } });
        } else if (provider === 'volanbusz') {
            stops = await db.Volanbusz_stops.findAll({ where: { stop_name: stopName } });
            stopIds = stops.map((stop) => stop.stop_id);
            route_stop = await db.Volanbusz_route_stop.findAll({ where: { stop_id: stopIds } });
            routeIds = route_stop.map((route_stop) => route_stop.route_id);
            routes = await db.Volanbusz_routes.findAll({ where: { route_id: routeIds } });
        } else {
            routes = [];
        }

        if (routes && routes.length > 0) {
            res.status(200).send(routes);
        } else {
            return res.status(404).send({ Error: "No routes found" });
        }
    } catch (error) {
        console.error('Error in /searchStop:', err);
        return res.status(500).send({ Error: "An error occurred while searching for stops" });
    }

});



fastify.post('/addFavourite', async (req, res) => {
    const name = req.query.user;
    const user = await db.Users.findAll({ where: { name: name } });
    const user_id = user[0].dataValues.id;
    let agency_id = req.query.agencyId;
    let route_id = req.query.routeId;
    const route_short_name = req.query.route_short_name;
    const route_long_name = req.query.route_long_name;

    if (typeof agency_id !== 'string') {
        agency_id = String(agency_id);
    }

    if (typeof route_id !== 'string') {
        route_id = String(route_id);
    }

    try {
        const favorite = await db.Favourites.create({
            agency_id,
            route_id,
            route_short_name,
            route_long_name,
            user_id,
        });

        return res.status(201).send(favorite);
    } catch (error) {
        console.error('Error adding favourite:', error);
        return res.status(500).send('Error adding favourite');
    }
})

fastify.get('/getFavorites', async (req, res) => {
    const name = req.query.user;
    console.log(name);
    const user = await db.Users.findAll({ where: { name: name } });
    const user_id = user[0].dataValues.id;


    try {
        const favorites = await db.Favourites.findAll({
            where: { user_id: user_id },
        });

        res.status(200).send(favorites);
    } catch (error) {
        console.error('Error getting favorites:', error);
        res.status(500).send('Error getting favorites');
    }
});

fastify.delete('/removeFavorite', async (req, res) => {
    const user = await db.Users.findAll({ where: { name: req.query.user } });
    const user_id = user[0].dataValues.id;
    const route_id = req.query.routeId;

    try {
        await db.Favourites.destroy({
            where: {
                route_id: route_id,
                user_id: user_id,
            },
        });

        return res.status(200).send({ success: true });
    } catch (error) {
        console.error('Error removing favorite:', error);
        return res.status(500).send('Error removing favorite');
    }
});

fastify.get('/checkFavourite', async (req, res) => {
    const user = await db.Users.findAll({ where: { name: req.query.user } });
    const user_id = user[0].dataValues.id;
    let route_id = req.query.routeId;
    if (typeof route_id !== 'string') {
        route_id = String(route_id);
    }

    try {
        const favorite = await db.Favourites.findOne({
            where: {
                user_id: user_id,
                route_id: route_id,
            },
        });
        console.log(favorite);
        return res.status(200).send({ isFavorite: !!favorite });
    } catch (error) {
        console.error('Error checking favorite:', error);
        return res.status(500).send('Error checking favorite');
    }
});


const start = async () => {
    try {
        await fastify.listen({ port: 3000 })
    } catch (err) {
        fastify.log.error(err)
        process.exit(1);
    }
}
start()