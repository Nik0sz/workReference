var DataTypes = require("sequelize").DataTypes;
var _budapest_routes = require("./budapest_routes");
var _budapest_stop_times = require("./budapest_stop_times");
var _budapest_stops = require("./budapest_stops");
var _budapest_trips = require("./budapest_trips");
var _mav_routes = require("./mav_routes");
var _mav_stop_times = require("./mav_stop_times");
var _mav_stops = require("./mav_stops");
var _mav_trips = require("./mav_trips");
var _volanbusz_routes = require("./volanbusz_routes");
var _volanbusz_stop_times = require("./volanbusz_stop_times");
var _volanbusz_stops = require("./volanbusz_stops");
var _volanbusz_trips = require("./volanbusz_trips");
var _users = require("./users");
var _budapest_route_stop = require("./budapest_route_stop");
var _mav_route_stop = require("./mav_route_stop");
var _volanbusz_route_stop = require("./volanbusz_route_stop");
var _favourites = require("./favourites");

function initModels(sequelize) {
  var budapest_routes = _budapest_routes(sequelize, DataTypes);
  var budapest_stop_times = _budapest_stop_times(sequelize, DataTypes);
  var budapest_stops = _budapest_stops(sequelize, DataTypes);
  var budapest_trips = _budapest_trips(sequelize, DataTypes);
  var mav_routes = _mav_routes(sequelize, DataTypes);
  var mav_stop_times = _mav_stop_times(sequelize, DataTypes);
  var mav_stops = _mav_stops(sequelize, DataTypes);
  var mav_trips = _mav_trips(sequelize, DataTypes);
  var volanbusz_routes = _volanbusz_routes(sequelize, DataTypes);
  var volanbusz_stop_times = _volanbusz_stop_times(sequelize, DataTypes);
  var volanbusz_stops = _volanbusz_stops(sequelize, DataTypes);
  var volanbusz_trips = _volanbusz_trips(sequelize, DataTypes);
  var users = _users(sequelize, DataTypes);
  var budapest_route_stop = _budapest_route_stop(sequelize, DataTypes);
  var mav_route_stop = _mav_route_stop(sequelize, DataTypes);
  var volanbusz_route_stop = _volanbusz_route_stop(sequelize, DataTypes);
  var favourites = _favourites(sequelize, DataTypes);

  return {
    budapest_routes,
    budapest_stop_times,
    budapest_stops,
    budapest_trips,
    mav_routes,
    mav_stop_times,
    mav_stops,
    mav_trips,
    volanbusz_routes,
    volanbusz_stop_times,
    volanbusz_stops,
    volanbusz_trips,
    users,
    budapest_route_stop,
    mav_route_stop,
    volanbusz_route_stop,
    favourites,
  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;