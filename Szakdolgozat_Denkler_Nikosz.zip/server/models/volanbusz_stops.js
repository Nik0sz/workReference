const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
  class Volanbusz_stops extends Model {
    static associate(models) {
      this.hasMany(models.Volanbusz_stop_times, {
        foreignKey: 'stop_id',
        sourceKey: 'stop_id',
        as: 'stopTimes',
      })

      this.belongsToMany(models.Volanbusz_trips, {
        through: models.Volanbusz_stop_times,
        foreignKey: 'stop_id',
        otherKey: 'trip_id',
        as: 'trips',
      })
      this.belongsToMany(models.Volanbusz_routes, {
        through: models.Volanbusz_route_stop,
        foreignKey: 'stop_id',
        otherKey: 'route_id',
        as: 'routes',
      })
    }
  }
  Volanbusz_stops.init(
    {
      stop_id: {
        type: DataTypes.STRING(255),
        primaryKey: true,
        allowNull: true
      },
      stop_name: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      stop_lat: {
        type: DataTypes.DOUBLE,
        allowNull: true
      },
      stop_lon: {
        type: DataTypes.DOUBLE,
        allowNull: true
      },
      location_type: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      parent_station: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      platform_code: {
        type: DataTypes.INTEGER,
        allowNull: true
      }
    }, {
    sequelize,
    modelName: 'Volanbusz_stops',
    timestamps: false
  });
  return Volanbusz_stops;
};
