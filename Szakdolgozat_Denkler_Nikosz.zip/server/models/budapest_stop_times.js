const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
  class Budapest_stop_times extends Model {
    static associate(models) {

    }
  }
  Budapest_stop_times.init(
    {
      trip_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      stop_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      arrival_time: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      departure_time: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      stop_sequence: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      stop_headsign: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      pickup_type: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      drop_off_type: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      shape_dist_traveled: {
        type: DataTypes.DOUBLE,
        allowNull: true
      },
      // id: {
      //   type: DataTypes.INTEGER,
      //   primaryKey: true,
      //   allowNull: true
      // }
    }, {
    sequelize,
    modelName: 'Budapest_stop_times',
    tableName: 'budapest_stop_times',
    timestamps: false
  });
  return Budapest_stop_times;
};
