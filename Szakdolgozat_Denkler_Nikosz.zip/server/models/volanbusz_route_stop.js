const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
    class Volanbusz_route_stop extends Model {
        static associate(models) {

        }
    }
    Volanbusz_route_stop.init(
        {
            route_id: {
                type: DataTypes.STRING(255),
                allowNull: true,
                primaryKey: true,
            },
            stop_id: {
                type: DataTypes.STRING(255),
                allowNull: true,
                primaryKey: true,
            },
            stop_sequence: {
                type: DataTypes.INTEGER,
                allowNull: true,
            },
        }, {
        sequelize,
        modelName: 'Volanbusz_route_stop',
        tableName: 'volanbusz_route_stop',
        timestamps: false
    }
    )
    return Volanbusz_route_stop;
}