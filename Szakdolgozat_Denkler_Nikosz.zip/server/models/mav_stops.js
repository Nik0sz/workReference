const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
  class Mav_stops extends Model {
    static associate(models) {
      this.hasMany(models.Mav_stop_times, {
        foreignKey: 'stop_id',
        sourceKey: 'stop_id',
        as: 'stopTimes',
      })

      this.belongsToMany(models.Mav_trips, {
        through: models.Mav_stop_times,
        foreignKey: 'stop_id',
        otherKey: 'trip_id',
        as: 'trips',
      })
      this.belongsToMany(models.Mav_routes, {
        through: models.Mav_route_stop,
        foreignKey: 'stop_id',
        otherKey: 'route_id',
        as: 'routes',
      })
    }
  }
  Mav_stops.init(
    {
    stop_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      allowNull: true
    },
    stop_code: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    stop_name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    stop_desc: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    stop_lat: {
      type: DataTypes.DOUBLE,
      allowNull: true
    },
    stop_lon: {
      type: DataTypes.DOUBLE,
      allowNull: true
    },
    zone_id: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    stop_url: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    location_type: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    parent_station: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    stop_timezone: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    wheelchair_boarding: {
      type: DataTypes.INTEGER,
      allowNull: true
    }
  }, {
    sequelize,
    modelName: 'Mav_stops',
    timestamps: false,
  });
  return Mav_stops;
};
