const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
  class Volanbusz_trips extends Model {
    static associate(models) {

    }
  }
  Volanbusz_trips.init(
    {
      route_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      trip_id: {
        type: DataTypes.STRING(255),
        primaryKey: true,
        allowNull: true
      },
      service_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      trip_short_name: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      direction_id: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      shape_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      wheelchair_accessible: {
        type: DataTypes.STRING(255),
        allowNull: true
      }
    }, {
    sequelize,
    modelName: 'Volanbusz_trips',
    timestamps: false
  });
  return Volanbusz_trips;
};
