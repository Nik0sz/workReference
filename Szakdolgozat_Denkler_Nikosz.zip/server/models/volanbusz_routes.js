const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
  class Volanabusz_routes extends Model {
    static associate(models) {
      this.hasMany(models.Volanbusz_trips, {
        foreignKey: 'route_id',
        sourceKey: 'route_id',
        as: 'trips',
      });
      this.belongsToMany(models.Volanbusz_stops, {
        through: models.Volanbusz_route_stop,
        foreignKey: 'route_id',
        otherKey: 'stop_id',
        as: 'stops',
      })
    }
  }
  Volanabusz_routes.init(
    {
      agency_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_id: {
        type: DataTypes.STRING(255),
        primaryKey: true,
        allowNull: true
      },
      route_short_name: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_long_name: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_type: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      route_url: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_network: {
        type: DataTypes.STRING(255),
        allowNull: true
      }
    }, {
    sequelize,
    modelName: 'Volanbusz_routes',
    timestamps: false
  });
  return Volanabusz_routes;
};
