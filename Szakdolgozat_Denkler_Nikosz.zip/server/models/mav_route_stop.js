const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
    class Mav_route_stop extends Model {
        static associate(models) {

        }
    }
    Mav_route_stop.init(
        {
            route_id: {
                type: DataTypes.DOUBLE,
                allowNull: true,
                primaryKey: true,
            },
            stop_id: {
                type: DataTypes.INTEGER,
                allowNull: true,
                primaryKey: true,
            },
            stop_sequence: {
                type: DataTypes.INTEGER,
                allowNull: true,
            },
        }, {
        sequelize,
        modelName: 'Mav_route_stop',
        tableName: 'mav_route_stop',
        timestamps: false
    }
    )
    return Mav_route_stop;
}