const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
    class Favourites extends Model {
        static associate(models) {

        }
    }
    Favourites.init(
        {
            id: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                allowNull: true
            },
            agency_id: {
                type: DataTypes.STRING(255),
                allowNull: true,
            },
            route_id: {
                type: DataTypes.STRING(255),
                allowNull: true,
            },
            route_short_name: {
                type: DataTypes.STRING(255),
                allowNull: true,
            },
            route_long_name: {
                type: DataTypes.STRING(255),
                allowNull: true,
            },
            user_id: {
                type: DataTypes.INTEGER,
                allowNull: true,
            },
        }, {
        sequelize,
        modelName: 'Favourites',
        timestamps: false
    });
    return Favourites;
};
