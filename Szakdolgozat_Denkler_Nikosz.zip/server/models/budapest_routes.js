const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
  class Budapest_routes extends Model {
    static associate(models) {
      this.hasMany(models.Budapest_trips, {
        foreignKey: 'route_id',
        sourceKey: 'route_id',
        as: 'trips',
      });
      this.belongsToMany(models.Budapest_stops, {
        through: models.Budapest_route_stop,
        foreignKey: 'route_id',
        otherKey: 'stop_id',
        as: 'stops',
      })
    }
  }
  Budapest_routes.init(
    {
      agency_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_id: {
        type: DataTypes.STRING(255),
        primaryKey: true,
        allowNull: true
      },
      route_short_name: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_long_name: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_type: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_desc: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_color: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_text_color: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_sort_order: {
        type: DataTypes.INTEGER,
        allowNull: true
      }
    }, {
    sequelize,
    modelName: "Budapest_routes",
    tableName: "budapest_routes",
    timestamps: false,
  }
  )
  return Budapest_routes;
};
