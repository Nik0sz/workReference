const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
  class Volanbusz_stop_times extends Model {
    static associate(models) {

    }
  }
  Volanbusz_stop_times.init(
    {
      trip_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      stop_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      arrival_time: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      departure_time: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      stop_sequence: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      pickup_type: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      drop_off_type: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      shape_dist_traveled: {
        type: DataTypes.DOUBLE,
        allowNull: true
      },
      // id: {
      //   type: DataTypes.INTEGER,
      //   primaryKey: true,
      //   allowNull: true
      // }
    }, {
    sequelize,
    tableName: 'Volanbusz_stop_times',
    timestamps: false
  });
  return Volanbusz_stop_times;
};
