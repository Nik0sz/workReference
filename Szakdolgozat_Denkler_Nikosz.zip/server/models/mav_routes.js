const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
  class Mav_routes extends Model {
    static associate(models) {
      this.hasMany(models.Mav_trips, {
        foreignKey: 'route_id',
        sourceKey: 'route_id',
        as: 'trips',
      });
      this.belongsToMany(models.Mav_stops, {
        through: models.Mav_route_stop,
        foreignKey: 'route_id',
        otherKey: 'stop_id',
        as: 'stops',
      })
    }
  }
  Mav_routes.init(
    {
      route_id: {
        type: DataTypes.DOUBLE,
        primaryKey: true,
        allowNull: true
      },
      agency_id: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      route_short_name: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_long_name: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_desc: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_type: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      route_url: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_color: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      route_text_color: {
        type: DataTypes.STRING(255),
        allowNull: true
      }
    }, {
    sequelize,
    modelName: 'Mav_routes',
    timestamps: false,
  });
  return Mav_routes;
};
