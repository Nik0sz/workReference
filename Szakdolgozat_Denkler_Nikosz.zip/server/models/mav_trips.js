const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
  class Mav_trips extends Model {
    static associate(models) {

    }
  }
  Mav_trips.init(
    {
      route_id: {
        type: DataTypes.DOUBLE,
        allowNull: true
      },
      service_id: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      trip_id: {
        type: DataTypes.STRING(255),
        primaryKey: true,
        allowNull: true
      },
      trip_headsign: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      trip_short_name: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      direction_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      block_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      shape_id: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      wheelchair_accessible: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      bikes_allowed: {
        type: DataTypes.STRING(255),
        allowNull: true
      }
    }, {
    sequelize,
    modelName: 'Mav_trips',
    timestamps: false
  });
  return Mav_trips;
};
