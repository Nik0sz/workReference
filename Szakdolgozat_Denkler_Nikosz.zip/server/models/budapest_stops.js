const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
  class Budapest_stops extends Model {
    static associate(models) {
      this.hasMany(models.Budapest_stop_times, {
        foreignKey: 'stop_id',
        sourceKey: 'stop_id',
        as: 'stopTimes',
      })

      this.belongsToMany(models.Budapest_trips, {
        through: models.Budapest_stop_times,
        foreignKey: 'stop_id',
        otherKey: 'trip_id',
        as: 'trips',
      })
      this.belongsToMany(models.Budapest_routes, {
        through: models.Budapest_route_stop,
        foreignKey: 'stop_id',
        otherKey: 'route_id',
        as: 'routes',
      })
    }
  }
  Budapest_stops.init(
    {
      stop_id: {
        type: DataTypes.STRING(255),
        primaryKey: true,
        allowNull: true
      },
      stop_name: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      stop_lat: {
        type: DataTypes.DOUBLE,
        allowNull: true
      },
      stop_lon: {
        type: DataTypes.DOUBLE,
        allowNull: true
      },
      stop_code: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      location_type: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      location_sub_type: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      parent_station: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      wheelchair_boarding: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      stop_direction: {
        type: DataTypes.INTEGER,
        allowNull: true
      }
    }, {
    sequelize,
    modelName: "Budapest_stops",
    tableName: 'budapest_stops',
    timestamps: false,
  });
  return Budapest_stops
};
