const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
  class Budapest_trips extends Model {
    static associate(models) {

    }
  }
  Budapest_trips.init(
    {
      route_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      trip_id: {
        type: DataTypes.STRING(255),
        primaryKey: true,
        allowNull: true,
      },
      service_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      trip_headsign: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      direction_id: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      block_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      shape_id: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      wheelchair_accessible: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      bikes_allowed: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      boarding_door: {
        type: DataTypes.INTEGER,
        allowNull: true
      }
    }, {
    sequelize,
    modelName: "Budapest_trips",
    tableName: "budapest_trips",
    timestamps: false,
    }
  )
  return Budapest_trips
};
