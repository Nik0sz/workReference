const { Model } = require('sequelize');
module.exports = function (sequelize, DataTypes) {
  class Users extends Model {
    static associate(models) {
      
    }
  }
  Users.init(
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: true
      },
      name: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      email: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      password: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
    }, {
    sequelize,
    modelName: 'Users',
    timestamps: false
  });
  return Users;
};
