// const fastify = require('fastify');
// const db = require('./models'); // Import your Sequelize setup from index.


// fastify.get('/searchVehicle', async (req, res) => {
//     const routes = await db.Budapest_routes.findAll();
//     res.send(routes);
// });

/*fastify.get('/searchRoute', async (request, reply) => {
  const { provider, vehicle } = request.query;
  let routes;

  switch (provider) {
    case 'budapest':
      routes = db.Budapest_routes;
      break;
    case 'mav':
      routes = db.Mav_routes;
      break;
    case 'volanbusz':
      routes = db.Volanbusz_routes;
      break;
    default:
      return reply.code(400).send({ error: 'Invalid provider' });
  }

  try {
    const filteredRoutes = await routes.findAll({
      where: {
        [Sequelize.Op.or]: [
          { route_short_name: { [Sequelize.Op.like]: `%${vehicle}%` } },
          { route_long_name: { [Sequelize.Op.like]: `%${vehicle}%` } },
        ],
      },
    });

    const matchingRouteNames = filteredRoutes.map((route) => {
      const shortName = route.route_short_name || '';
      const longName = route.route_long_name || '';
      return `${shortName}${longName ? ` ${longName}` : ''}`;
    });

    reply.send(matchingRouteNames);
  } catch (error) {
    console.error('Error:', error);
    reply.code(500).send({ error: 'Internal Server Error' });
  }
});*/
