# Create a list to store modified lines
modified_lines = []

# Open the text file for reading
with open('./budapest_gtfs/trips.txt', 'r') as file:
    # Iterate through the lines
    for line in file:
        # Check if the second to last character is a comma
        if line[-2] == ',':
            # Remove the second to last character (comma) and add the modified line to the list
            modified_lines.append(line[:-2] + '\n')
        else:
            # Keep the line as is
            modified_lines.append(line)

# Open the text file for writing (this will overwrite the original file)
with open('./budapest_gtfs/trips.txt', 'w') as file:
    # Write the modified lines back to the file
    file.writelines(modified_lines)



with open('./budapest_gtfs/budapest_routes.csv','r',encoding='utf-8') as f, open('./budapest_gtfs/budapest_routes_', 'w', encoding='utf-8') as out:
    data = f.read()
    data = data.split('\n')
    for i in data:
        splitted = i.split(',')
        output = ''
        if(len(splitted) == 9):
            splitted[5] = "\"" + splitted[5] + "\""
            for j in splitted:
                output = output + ',' + j
        
            output = output[1:len(output)] + '\n'
        elif (len(splitted) > 9 and splitted[5][0] != "\""):
            treshold = len(splitted) - 9
            fifth = ''
            for j in splitted[5:5+treshold+1]:
                fifth = fifth + j

            splitted[5] = "\"" + fifth + "\""
            for j in splitted:
                output = output + ',' + j
            output = output[1:len(output)] + '\n'
        else:
            output = i + '\n'
        out.write(output)

with open('./volanbusz_gtfs/volanbusz_routes.csv','r',encoding='utf-8') as f, open('./volanbusz_gtfs/volanbusz_routes_.csv', 'w', encoding='utf-8') as out:
    data = f.read()
    data = data.split('\n')
    for i in data:
        splitted = i.split(',')
        output = ''
        if(len(splitted) == 7):
            splitted[3] = "\"" + splitted[3] + "\""
            for j in splitted:
                output = output + ',' + j
        
            output = output[1:len(output)] + '\n'
        elif (len(splitted) > 7 and splitted[3][0] != "\""):
            treshold = len(splitted) - 9
            fifth = ''
            for j in splitted[3:3+treshold+1]:
                fifth = fifth + j

            splitted[3] = "\"" + fifth + "\""
            for j in splitted:
                output = output + ',' + j
            output = output[1:len(output)] + '\n'
        else:
            output = i + '\n'
        out.write(output)