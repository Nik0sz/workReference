import csv

# Define a function to convert a row to a dictionary for stops
def stop_row_to_dict(row):
    return {
        "stop_id": row[0],
        "stop_name": row[1],
        "stop_lat": row[2],
        "stop_lon": row[3],
        "location_type": row[4],
        "parent_station": row[5],
        "platform_code": row[6]
    }

# Define a function to convert a row to a dictionary for stop times
def stop_time_row_to_dict(row):
    return {
        "trip_id": row[0],
        "stop_id": row[1],
        "arrival_time": row[2],
        "departure_time": row[3],
        "stop_sequence": row[4],
        "pickup_type": row[5],
        "drop_off_type": row[6],
        "shape_dist_traveled": row[7]
    }

# Define a function to convert a row to a dictionary for routes
def route_row_to_dict(row):
    return {
        "agency_id": row[0],
        "route_id": row[1],
        "route_short_name": row[2],
        "route_long_name": row[3],
        "route_type": row[4],
        "route_url": row[5],
        "route_network": row[6]
    }

# Define a function to convert a row to a dictionary for trips
def trip_row_to_dict(row):
    return {
        "route_id": row[0],
        "trip_id": row[1],
        "service_id": row[2],
        "trip_short_name": row[3],
        "direction_id": row[4],
        "shape_id": row[5],
        "wheelchair_accessible": row[6]
    }

# Convert stop.txt to CSV
with open('./volanbusz_gtfs/stops.txt', 'r') as txtfile:
    reader = csv.reader(txtfile)
    next(reader)
    with open('./volanbusz_gtfs/volanbusz_stops.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['stop_id', 'stop_name', 'stop_lat', 'stop_lon', 'location_type', 'parent_station', 'platform_code'])
        for row in reader:
            writer.writerow(row)

# Convert stop_times.txt to CSV
with open('./volanbusz_gtfs/stop_times.txt', 'r') as txtfile:
    reader = csv.reader(txtfile)
    next(reader)
    with open('./volanbusz_gtfs/volanbusz_stop_times.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['trip_id', 'stop_id', 'arrival_time', 'departure_time', 'stop_sequence', 'pickup_type', 'drop_off_type', 'shape_dist_traveled'])
        for row in reader:
            writer.writerow(row)

# Convert routes.txt to CSV
with open('./volanbusz_gtfs/routes.txt', 'r') as txtfile:
    reader = csv.reader(txtfile)
    next(reader)
    with open('./volanbusz_gtfs/volanbusz_routes.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['agency_id', 'route_id', 'route_short_name', 'route_long_name', 'route_type', 'route_url', 'route_network'])
        for row in reader:
            writer.writerow(row)

# Convert trips.txt to CSV
with open('./volanbusz_gtfs/trips.txt', 'r') as txtfile:
    reader = csv.reader(txtfile)
    next(reader)
    with open('./volanbusz_gtfs/volanbusz_trips.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['route_id', 'trip_id', 'service_id', 'trip_short_name', 'direction_id', 'shape_id', 'wheelchair_accessible'])
        for row in reader:
            writer.writerow(row)

