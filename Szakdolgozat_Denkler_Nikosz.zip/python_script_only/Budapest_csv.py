import csv

# Define a function to convert a row to a dictionary for stops
def stop_row_to_dict(row):
    return {
        "stop_id": row[0],
        "stop_name": row[1],
        "stop_lat": row[2],
        "stop_lon": row[3],
        "stop_code": row[4],
        "location_type": row[5],
        "location_sub_type": row[6],
        "parent_station": row[7],
        "wheelchair_boarding": row[8],
        "stop_direction": row[9]
    }

# Define a function to convert a row to a dictionary for stop times
def stop_time_row_to_dict(row):
    return {
        "trip_id": row[0],
        "stop_id": row[1],
        "arrival_time": row[2],
        "departure_time": row[3],
        "stop_sequence": row[4],
        "stop_headsign": row[5],
        "pickup_type": row[6],
        "drop_off_type": row[7],
        "shape_dist_traveled": row[8]
    }

# Define a function to convert a row to a dictionary for routes
def route_row_to_dict(row):
    return {
        "agency_id": row[0],
        "route_id": row[1],
        "route_short_name": row[2],
        "route_long_name": row[3],
        "route_type": row[4],
        "route_desc": row[5],
        "route_color": row[6],
        "route_text_color": row[7],
        "route_sort_order": row[8]
    }

def trip_row_to_dict(row):
    return {
        "route_id": row[0],
        "trip_id": row[1],
        "service_id": row[2],
        "trip_headsign": row[3],
        "direction_id": row[4],
        "block_id": row[5],
        "shape_id": row[6],
        "wheelchair_accessible": row[7],
        "bikes_allowed": row[8],
        "boarding_door": row[9]
    }

#Convert stops.txt to CSV
with open('./budapest_gtfs/stops.txt', 'r') as txtfile:
    reader = csv.reader(txtfile)
    next(reader)
    with open('./budapest_gtfs/budapest_stops.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['stop_id', 'stop_name', 'stop_lat', 'stop_lon', 'stop_code', 'location_type', 'location_sub_type', 'parent_station', 'wheelchair_boarding', 'stop_direction'])
        for row in reader:
            writer.writerow(row)

# Convert stop_times.txt to CSV
with open('./budapest_gtfs/stop_times.txt', 'r') as txtfile:
    reader = csv.reader(txtfile)
    next(reader)
    with open('./budapest_gtfs/budapest_stop_times.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['trip_id', 'stop_id', 'arrival_time', 'departure_time', 'stop_sequence', 'stop_headsign', 'pickup_type', 'drop_off_type', 'shape_dist_traveled'])
        for row in reader:
            writer.writerow(row)

# Convert routes.txt to CSV
with open('./budapest_gtfs/routes.txt', 'r') as txtfile:
    reader = csv.reader(txtfile)
    next(reader)
    with open('./budapest_gtfs/budapest_routes.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['agency_id', 'route_id', 'route_short_name', 'route_long_name', 'route_type', 'route_desc', 'route_color', 'route_text_color', 'route_sort_order'])
        for row in reader:
            writer.writerow(row)

with open('./budapest_gtfs/trips.txt', 'r') as txtfile:
    reader = csv.reader(txtfile)
    next(reader)
    with open('./budapest_gtfs/budapest_trips.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['route_id', 'trip_id', 'service_id', 'trip_headsign', 'direction_id', 'block_id', 'shape_id', 'wheelchair_accessible', 'bikes_allowed', 'boarding_door'])
        for row in reader:
            writer.writerow(row)
