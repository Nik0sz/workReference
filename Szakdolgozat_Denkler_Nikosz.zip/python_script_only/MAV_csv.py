import csv

# Define a function to convert a row to a dictionary for routes
def route_row_to_dict(row):
    return {
        "route_id": row[0],
        "agency_id": row[1],
        "route_short_name": row[2],
        "route_long_name": row[3],
        "route_desc": row[4],
        "route_type": row[5],
        "route_url": row[6],
        "route_color": row[7],
        "route_text_color": row[8]
    }

# Define a function to convert a row to a dictionary for stops
def stop_row_to_dict(row):
    return {
        "stop_id": row[0],
        "stop_code": row[1],
        "stop_name": row[2],
        "stop_desc": row[3],
        "stop_lat": row[4],
        "stop_lon": row[5],
        "zone_id": row[6],
        "stop_url": row[7],
        "location_type": row[8],
        "parent_station": row[9],
        "stop_timezone": row[10],
        "wheelchair_boarding": row[11]
    }

# Define a function to convert a row to a dictionary for stop times
def stop_time_row_to_dict(row):
    return {
        "trip_id": row[0],
        "arrival_time": row[1],
        "departure_time": row[2],
        "stop_id": row[3],
        "stop_sequence": row[4],
        "stop_headsign": row[5],
        "pickup_type": row[6],
        "drop_off_type": row[7]
    }

# Define a function to convert a row to a dictionary for trips
def trip_row_to_dict(row):
    return {
        "route_id": row[0],
        "service_id": row[1],
        "trip_id": row[2],
        "trip_headsign": row[3],
        "trip_short_name": row[4],
        "direction_id": row[5],
        "block_id": row[6],
        "shape_id": row[7],
        "wheelchair_accessible": row[8],
        "bikes_allowed": row[9]
    }

# Convert stops.txt to CSV
with open('./mav_gtfs/stops.txt', 'r') as txtfile:
    reader = csv.reader(txtfile)
    next(reader)
    with open('./mav_gtfs/mav_stops.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['stop_id', 'stop_code', 'stop_name', 'stop_desc', 'stop_lat', 'stop_lon', 'zone_id', 'stop_url', 'location_type', 'parent_station', 'stop_timezone', 'wheelchair_boarding'])
        for row in reader:
            writer.writerow(row)

# Convert routes.txt to CSV
with open('./mav_gtfs/routes.txt', 'r') as txtfile:
    reader = csv.reader(txtfile)
    next(reader)
    with open('./mav_gtfs/mav_routes.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['route_id', 'agency_id', 'route_short_name', 'route_long_name', 'route_desc', 'route_type', 'route_url', 'route_color', 'route_text_color'])
        for row in reader:
            writer.writerow(row)

# Convert stop_times.txt to CSV
with open('./mav_gtfs/stop_times.txt', 'r') as txtfile:
    reader = csv.reader(txtfile)
    next(reader)
    with open('./mav_gtfs/mav_stop_times.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence', 'stop_headsign', 'pickup_type', 'drop_off_type'])
        for row in reader:
            writer.writerow(row)

# Convert trips.txt to CSV
with open('./mav_gtfs/trips.txt', 'r') as txtfile:
    reader = csv.reader(txtfile)
    next(reader)
    with open('./mav_gtfs/mav_trips.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['route_id', 'service_id', 'trip_id', 'trip_headsign', 'trip_short_name', 'direction_id', 'block_id', 'shape_id', 'wheelchair_accessible', 'bikes_allowed'])
        for row in reader:
            writer.writerow(row)
